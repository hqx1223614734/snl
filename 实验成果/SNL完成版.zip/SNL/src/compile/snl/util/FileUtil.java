package compile.snl.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileUtil {
    public static String readFromFile(String filename){
        StringBuilder result = new StringBuilder();
        File file = new File(filename);
        try {
            FileReader reader = new FileReader(file);
            int c = 0;
            while((c = reader.read())!=-1){
                result.append((char)c);
            }
        } catch (FileNotFoundException e) {
            System.out.println("�ļ�δ�ҵ�");
        } catch (IOException e) {
            System.out.println("�ļ���ȡ����");
        }
        return result.toString();
    }
}
