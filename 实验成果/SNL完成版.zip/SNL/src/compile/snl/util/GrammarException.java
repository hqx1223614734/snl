package compile.snl.util;

public class GrammarException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public GrammarException(String exceptionMessage){
		super(exceptionMessage);
	}

}
