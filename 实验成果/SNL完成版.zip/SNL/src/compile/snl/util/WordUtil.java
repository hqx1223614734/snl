package compile.snl.util;

import java.util.HashSet;

public class WordUtil {
    private static HashSet<String> keyWord = new HashSet<>();
    static {
        String[] words =
                {
                        "program","type","var","procedure","begin","end","array","of","record","if","then",
                        "else","fi","while","do","endwh","read","write","return","integer","char"
                };
        for(int i = 0;i<words.length;i++){
            keyWord.add(words[i]);
        }
    }
    //是否为保留字
    public static boolean isKetWord(String s){
        if(keyWord.contains(s)) return true;
        return false;
    }
    //是否为字母
    public static boolean isLetter(int ch)
    {
        if((ch>='A'&&ch<='Z')||(ch>='a'&&ch<='z'))
            return true;
        return false;
    }
    //是否为数字
    public static boolean isNumber(int ch)
    {
        if(ch>='0'&&ch<='9')
            return true;
        return false;
    }
}
