package compile.snl.lexianalysis;

import compile.snl.util.WordUtil;

import java.util.ArrayList;
import java.util.List;

public class WordScanner {
    private final int START = 0;              //初始状态
    private final int INLETTER =  1;          //读入首字符为字母
    private final int INNUMBER = 2;           //读入首字符为数字
    private final int INAPOSTROPHE = 3;       //读入首字符为'
    private final int INLEFT_BRACES = 4;      //读入首字符为{
    private final int INCOLON = 5;            //读入首字符为:
    private final int INDOT = 6;              //读入首字符为.

    private String src;
    private int state;
    private int position;
    private int line;
    private List<String> errors;
    private List<Integer> constantList;
    private List<String> idList;
    public WordScanner(String src){
    //    System.out.println(src.charAt(position));
        this.src = src;
        this.state = 0;
        this.position = 0;
        this.line = 1;
        this.errors = new ArrayList<>();
        this.constantList = new ArrayList<>();
        this.idList = new ArrayList<>();
    }
    public Token getNextWord(){
        state = START;
        while (true){
            switch (state){
                case START:{
                    char a = ' ';
                    while(isBlank(a)&&hasNext()){
                        if(a == '\n') line++;
                        a = getNext();
                    }
                    if(isBlank(a)) return null;
                    if(WordUtil.isLetter(a)) state = INLETTER;
                    else if(WordUtil.isNumber(a)) state = INNUMBER;
                    else{
                        switch (a){
                            case '+':return new Token(WordType.ADD,-1,line);
                            case '-':return new Token(WordType.SUB,-1,line);
                            case '*':return new Token(WordType.MUL,-1,line);
                            case '/':return new Token(WordType.DIV,-1,line);
                            case '<':return new Token(WordType.LESS,-1,line);
                            case '=':return new Token(WordType.EQUAL,-1,line);
                            case '(':return new Token(WordType.LEFT_PARENT,-1,line);
                            case ')':return new Token(WordType.RIGHT_PARENT,-1,line);
                            case '[':return new Token(WordType.LEFT_BRACKET,-1,line);
                            case ']':return new Token(WordType.RIGHT_BRACKET,-1,line);
                            case ';':return new Token(WordType.SEMICOLON,-1,line);
                            case ',':return new Token(WordType.COMMA,-1,line);
                            case '\'':state = INAPOSTROPHE;break;
                            case '.' :state = INDOT;break;
                            case ':' :state = INCOLON;break;
                            case '{' :state = INLEFT_BRACES;break;
                            default:errors.add("行数"+line+",非法字符"+a);
                        }
                    }
                    break;
                }
                case INLETTER:{
                    undoGet();
                    StringBuilder str = new StringBuilder();
                    str.append(getNext());
                    while(hasNext()&&(WordUtil.isLetter(src.charAt(position))||WordUtil.isNumber(src.charAt(position))))
                    {
                        str.append(getNext());
                    }
                    if(WordUtil.isKetWord(str.toString())){
                        return new Token(WordType.valueOf(str.toString().toUpperCase()),-1,line);
                    }
                    idList.add(str.toString());
                    return new Token(WordType.ID,idList.size()-1,line);
                }
                case INNUMBER:{
                    undoGet();
                    StringBuilder str = new StringBuilder();
                    str.append(getNext());
                    while(hasNext()&&WordUtil.isNumber(src.charAt(position)))
                    {
                        str.append(getNext());
                    }
                    constantList.add(Integer.parseInt(str.toString()));
                    return new Token(WordType.INTC,constantList.size()-1,line);
                }
                case INAPOSTROPHE:{
                    if(!hasNext()){
                        errors.add("未匹配的\',"+"行数："+line);
                    }
                    char c = getNext();
                    if(WordUtil.isLetter(c)||WordUtil.isNumber(c)){
                        constantList.add((int)c);
                        if(!hasNext()){
                            errors.add("未匹配的\',"+"行数："+line);
                        }else{
                            if(src.charAt(position)=='\'') position++;
                        }
                        return new Token(WordType.INTC,constantList.size()-1,line);
                    }else if(c=='\''){
                        errors.add("空字符\'\',"+"行数："+line);
                        state = START;
                    }
                    else{
                        errors.add("未匹配的\',"+"行数："+line);
                        state = START;
                        position--;
                    }
                    break;
                }
                case INLEFT_BRACES:{
                    int temp = line;
                    while(hasNext()&&src.charAt(position)!='}') {
                        if (src.charAt(position) == '\n')
                            line++;
                        position++;
                    }
                    if(!hasNext()) errors.add("未匹配的字符{,"+"行数："+temp);
                    else position++;
                    state = START;
                    break;
                }
                case INCOLON:{
                    if(hasNext()&&src.charAt(position)=='='){
                    	 position++;
                    	 return new Token(WordType.COLON_EQUAL,-1,line);
                    }
                       
                    else
                        errors.add("未识别的字符:,"+"行数："+line);
                }
                case INDOT:{
                    if(hasNext()&&src.charAt(position)=='.')
                    {
                    	position++;
                        return new Token(WordType.TWO_DOT,-1,line);
                    }
                    else
                    {
                        return new Token(WordType.DOT,-1,line);
                    }
                }
            }
        }
    }
    private boolean hasNext(){
        return position<src.length();
    }
    private char getNext(){
        return src.charAt(position++);
    }
    private void undoGet(){
        position --;
    }

    private boolean isBlank(int ch) {
        return ((char) ch == ' ' || ch == '\t' || ch == '\n' || ch == '\r');
    }

    public List<String> getErrors() {
        return errors;
    }

    public List<Integer> getConstantList() {
        return constantList;
    }

    public List<String> getIdList() {
        return idList;
    }

}
