package compile.snl.lexianalysis;

public class Token {
    private WordType type;
    private int position;   //��ʶ�������߳�������λ��.��Ϊ�������ţ���Ϊ-1
    private int line;       //����

    public Token(WordType type,int position,int line){
        this.type = type;
        this.position = position;
        this.line = line;
    }

    public WordType getType() {
        return type;
    }

    public void setType(WordType type) {
        this.type = type;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public int getLine() {
        return line;
    }

    public void setLine(int line) {
        this.line = line;
    }

    @Override
    public String toString() {
        return "("+type+","+position+","+line+")";
    }
}
