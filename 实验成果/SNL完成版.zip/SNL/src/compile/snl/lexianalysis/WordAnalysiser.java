package compile.snl.lexianalysis;

import java.util.ArrayList;
import java.util.List;

public class WordAnalysiser {
    private List<Token> tokenList;
    private WordScanner scanner;
    public WordAnalysiser(String input){
        scanner = new WordScanner(input);
        Token token = scanner.getNextWord();
        tokenList = new ArrayList<>();
        while(token!=null)
        {
            tokenList.add(token);
            token=scanner.getNextWord();
        }
    }

    public List<Token> getTokenList() {
        return tokenList;
    }

    public List<String> getErrors() {
        return scanner.getErrors();
    }

    public List<Integer> getConstantList() {
        return scanner.getConstantList();
    }

    public List<String> getIdList() {
        return scanner.getIdList();
    }
    
    public String getTokenMessage(){
    	StringBuilder str = new StringBuilder();
    	for(Token token:tokenList){
    		str.append(token.toString());
    		str.append('\n');
    	}
    	return str.toString();
    }
    
    public String getErrorMessage(){
    	StringBuilder str = new StringBuilder();
    	for(String s:scanner.getErrors()){
    		str.append(s);
    		str.append('\n');
    	}
    	return str.toString();
    }
}
