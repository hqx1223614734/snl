package compile.snl.wrods;

import java.util.ArrayList;


///////////////////////////////
// ����: 
// С��: 
// ����: 
/**
 * ����5�ֵ��ʣ����ռ������ؼ��֡���ʶ��������������
 * @author ��
 * @version 1.0
 * @created 06-6��-2018 21:13:56
 */
///////////////////////////////

public class FiveWords {

	/**
	 * ����
	 */
	private ArrayList<Word> constant;
	/**
	 * ��ʶ��
	 */
	private ArrayList<Word> identifier;
	/**
	 * �ؼ���
	 */
	private ArrayList<Word> keyword;
	/**
	 * ���ռ���
	 */
	private ArrayList<Word> nonterminal;
	/**
	 * ����
	 */
	private ArrayList<Word> symbol;

	public FiveWords(){
		constant = new ArrayList<Word>();
		identifier = new ArrayList<Word>();
		keyword = new ArrayList<Word>();
		nonterminal = new ArrayList<Word>();
		symbol = new ArrayList<Word>();
	}

	public ArrayList<Word> getConstant() {
		return constant;
	}

	public void setConstant(ArrayList<Word> constant) {
		this.constant = constant;
	}

	public ArrayList<Word> getIdentifier() {
		return identifier;
	}

	public void setIdentifier(ArrayList<Word> identifier) {
		this.identifier = identifier;
	}

	public ArrayList<Word> getKeyword() {
		return keyword;
	}

	public void setKeyword(ArrayList<Word> keyword) {
		this.keyword = keyword;
	}

	public ArrayList<Word> getNonterminal() {
		return nonterminal;
	}

	public void setNonterminal(ArrayList<Word> nonterminal) {
		this.nonterminal = nonterminal;
	}

	public ArrayList<Word> getSymbol() {
		return symbol;
	}

	public void setSymbol(ArrayList<Word> symbol) {
		this.symbol = symbol;
	}


}