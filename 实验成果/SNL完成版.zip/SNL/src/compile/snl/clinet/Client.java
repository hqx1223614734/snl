package compile.snl.clinet;

import compile.snl.gramanalysis.GrammaticalAnalysis;
import compile.snl.lexianalysis.WordAnalysiser;
import compile.snl.util.FileUtil;

import java.awt.*;
import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Client implements ActionListener{
    //��Ҫ�����ĳ�Ա����
    private JFileChooser fc = new JFileChooser();
    private File file = null;
    private JTextArea messageTextArea;
    private JTextArea treeTextArea;
    private JTextArea codeTextArea;
    private JTextArea tokenTextArea;
    private String fileContext = "";
    private WordAnalysiser wordAnalysiser;
    private GrammaticalAnalysis grammaticalAnalysis;

    private JFrame frmSnlcompiler;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Client window = new Client();
                    window.frmSnlcompiler.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }


    public Client() {
        initialize();
    }


    private void initialize() {
        frmSnlcompiler = new JFrame();
        frmSnlcompiler.setTitle("SNLCompiler");
        frmSnlcompiler.setBounds(100, 100, 491, 337);
        frmSnlcompiler.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmSnlcompiler.getContentPane().setLayout(new BorderLayout(0, 0));
        frmSnlcompiler.setExtendedState(JFrame.MAXIMIZED_BOTH);

        JMenuBar menuBar = new JMenuBar();
        frmSnlcompiler.getContentPane().add(menuBar, BorderLayout.NORTH);

        JMenu fileMenu = new JMenu("�ļ�");
        menuBar.add(fileMenu);

        final JMenuItem fileOpen = new JMenuItem("��");
        fileOpen.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                fc.setDialogTitle("���ļ�");
                fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
                File temp = new File("");
                fc.setCurrentDirectory(temp.getAbsoluteFile());
                fc.showOpenDialog(fileOpen);
                file = fc.getSelectedFile();
                if(file!=null) {
                    fileContext = FileUtil.readFromFile(file.getAbsolutePath());
                    codeTextArea.setText(fileContext);
                }
            }
        });
        fileMenu.add(fileOpen);

        JMenu compiler = new JMenu("����ѡ��");
        menuBar.add(compiler);

        JMenuItem runButton = new JMenuItem("����");
        runButton.addActionListener(this);
        compiler.add(runButton);

        JInternalFrame codeFrame = new JInternalFrame("code");
        codeFrame.setMaximizable(true);
        frmSnlcompiler.getContentPane().add(codeFrame, BorderLayout.CENTER);

        JScrollPane codeScrollPane = new JScrollPane();
        codeFrame.getContentPane().add(codeScrollPane, BorderLayout.CENTER);

        codeTextArea = new JTextArea();
        codeTextArea.setFont(new Font("����",Font.BOLD,32));
        codeScrollPane.setViewportView(codeTextArea);


        JInternalFrame tokenFrame = new JInternalFrame("token");
        tokenFrame.setPreferredSize(new Dimension(200, 34));
        tokenFrame.setMinimumSize(new Dimension(190, 34));

        frmSnlcompiler.getContentPane().add(tokenFrame, BorderLayout.WEST);
        tokenFrame.getContentPane().setLayout(new BorderLayout(0, 0));

        JScrollPane tokenScrollPane = new JScrollPane();
        tokenFrame.getContentPane().add(tokenScrollPane, BorderLayout.CENTER);

        tokenTextArea = new JTextArea();
        tokenTextArea.setEditable(false);
        tokenScrollPane.setViewportView(tokenTextArea);


        JInternalFrame treeFrame = new JInternalFrame("tree");
        treeFrame.setPreferredSize(new Dimension(700, 34));
        treeFrame.setMinimumSize(new Dimension(690, 34));

        frmSnlcompiler.getContentPane().add(treeFrame, BorderLayout.EAST);
        treeFrame.getContentPane().setLayout(new BorderLayout(0, 0));

        JScrollPane treeScrollPane = new JScrollPane();
        treeFrame.getContentPane().add(treeScrollPane, BorderLayout.CENTER);

        treeTextArea = new JTextArea();
        treeTextArea.setEditable(false);
        treeScrollPane.setViewportView(treeTextArea);


        JInternalFrame messageFrame = new JInternalFrame("message");
        messageFrame.setPreferredSize(new Dimension(55, 150));
        frmSnlcompiler.getContentPane().add(messageFrame, BorderLayout.SOUTH);

        JScrollPane messageScrollPane = new JScrollPane();
        messageFrame.getContentPane().add(messageScrollPane, BorderLayout.CENTER);

        messageTextArea = new JTextArea("\n\n\n\n");
        messageTextArea.setColumns(10);
        messageTextArea.setEditable(false);
        messageScrollPane.setViewportView(messageTextArea);

        tokenFrame.setVisible(true);
        treeFrame.setVisible(true);
        messageFrame.setVisible(true);
        codeFrame.setVisible(true);
    }


	@Override
	public void actionPerformed(ActionEvent arg0) {
		fileContext = codeTextArea.getText();
		wordAnalysiser = new WordAnalysiser(fileContext);
		//tokenTextArea.setFont(new Font("Courier", Font.PLAIN, 12));
		tokenTextArea.setText(wordAnalysiser.getTokenMessage());
		grammaticalAnalysis = new GrammaticalAnalysis(wordAnalysiser);
		grammaticalAnalysis.init();
		treeTextArea.setText(grammaticalAnalysis.getTreeMessage());
		messageTextArea.setText(wordAnalysiser.getErrorMessage()+grammaticalAnalysis.getErrorMessage());
	}

}


