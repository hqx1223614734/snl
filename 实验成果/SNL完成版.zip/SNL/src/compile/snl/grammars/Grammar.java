package compile.snl.grammars;


///////////////////////////////
// ����: 
// С��: 
// ����: 
/**
 * �﷨�ࣺ��һ���﷨
 * @author lenovo
 * @version 1.0
 * @created 06-6��-2018 21:13:56
 */
///////////////////////////////

public class Grammar {

	/**
	 * һ��Grammar
	 */
	private WordToWords gram;

	public Grammar(){
		gram = new WordToWords();
	}

	public Grammar(WordToWords wtws){
		gram = new WordToWords(wtws);
	}

	public void finalize() throws Throwable {

	}

	///////////////////////////////
	// ����: 
	// С��: 
	// ����: 
	/**
	 * ƥ�䵱ǰ�﷨
	 */
	///////////////////////////////

	public int matchgram(){
		return 0;
	}

	public WordToWords getGram() {
		return gram;
	}
	
	public void setGram(WordToWords gram) {
		this.gram = gram;
	}
}