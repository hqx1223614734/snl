package compile.snl.grammars;

import java.util.ArrayList;

import compile.snl.wrods.Word;

///////////////////////////////
// ����: 
// С��: 
// ����: 
/**
 * ��һ��Word��Ӧ���Word��Grammar��ThreeSet��
 * @author ��
 * @version 1.0
 * @created 06-6��-2018 21:13:57
 */
///////////////////////////////

public class WordToWords {


	private Word word;
	/**
	 * ��ӦWord�Ķ��Word
	 */
	private ArrayList<Word> words;

	public WordToWords(){
		word = new Word();
		words = new ArrayList<Word>();
	}
	
	public WordToWords(WordToWords wtws){
		word = new Word(wtws.getWord());
		words = new ArrayList<Word>();
		int len = wtws.getWords().size();
		for(int i=0; i<len; i++){
			words.add(new Word(wtws.getWords().get(i)));
		}
	}
	
	public void print(){
		System.out.print(word.getValue() + "|=>|");
		for(int i=0; i<words.size(); i++){
			System.out.print(words.get(i).getValue() + "|");
		}
		System.out.println();
	}
	
	public void finalize() throws Throwable {

	}
	public Word getWord() {
		return word;
	}
	
	public void setWord(Word word) {
		this.word = word;
	}
	
	public ArrayList<Word> getWords() {
		return words;
	}
	
	public void setWords(ArrayList<Word> words) {
		this.words = words;
	}

}