package compile.snl.grammars;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

import compile.snl.wrods.FiveWords;
import compile.snl.wrods.Word;
import file.util;


///////////////////////////////
// ����: 
// С��: 
// ����: 
/**
 * ���������﷨
 * @author lenovo
 * @version 1.0
 * @created 06-6��-2018 21:13:56
 */
///////////////////////////////

public class GrammarList {

	/**
	 * ����Ϊ List<Grammar>
	 */
	private static ArrayList<Grammar> glist;

	public GrammarList(){
		glist = null;
	}

	///////////////////////////////
	// ����: 
	// С��: 
	// ����: 
	/**
	 * ��ʼ�����е��ʵ�First��
	 */
	///////////////////////////////

	public void initFirst(){

	}

	///////////////////////////////
	// ����: 
	// С��: 
	// ����: 
	/**
	 * ��ʼ�����е��ʵ�Follow��
	 */
	///////////////////////////////

	public void initFollow(){

	}

	///////////////////////////////
	// ����: 
	// С��: 
	// ����: 
	/**
	 * ���������﷨
	 */
	///////////////////////////////

	public void initGrammars(){

	}

	///////////////////////////////
	// ����: 
	// С��: 
	// ����: 
	/**
	 * ��ʼ�����е��ʵ�Predict��
	 */
	///////////////////////////////

	public void initPredict(){

	}

	
	public ArrayList<Grammar> getGlist() {
		return glist;
	}
	
	
	public void setGlist(ArrayList<Grammar> glist) {
		this.glist = glist;
	}
	
	public static void print(){
		if(glist == null)return;
		for(int i=0; i<glist.size(); i++){
			glist.get(i).getGram().print();
		}
	}
	public static void printMap(HashMap<String, HashSet<String>> map){
		for(Iterator i = map.keySet().iterator(); i.hasNext();){
			String non = (String)i.next();
			String s = "";
			for(Iterator i1 = map.get(non).iterator(); i1.hasNext();){
				s += (String)i1.next();
			}
			System.out.print(non + " => " + s);
			System.out.println();
		}
	}
	public static void printPredict(HashMap<WordToWords, HashSet<String>> map){
		for(Iterator i = map.keySet().iterator(); i.hasNext();){
			WordToWords gram = (WordToWords)i.next();
			String non = gram.getWord().getValue();
			String s = "";
			for(int x = 0; x < gram.getWords().size(); x ++){
				s += gram.getWords().get(x).getValue();
			}
			s = non + " => " + s;
			String s1 = "";
			for(Iterator i1 = map.get(gram).iterator(); i1.hasNext();){
				s1 += "  " + (String)i1.next();
			}
			System.out.print(s + "            "+ s1);
			System.out.println();
		}
	}
	public static ArrayList<Grammar> trim(ArrayList<Grammar> glist){
		ArrayList<Grammar> newa = new ArrayList<Grammar>();
		for(int i = 0; i < glist.size(); i ++){
			String s = glist.get(i).getGram().getWord().getValue().trim();
			WordToWords w = new WordToWords();
			w.setWord(new Word("", s));
			w.setWords(glist.get(i).getGram().getWords());
			newa.add(new Grammar(w));
		}
		return newa;
	}
	public static void main(String[] args) {
//		glist = trim(util.read("E:\\ѧϰ��\\������\\����ԭ��\\����ԭ��ʵ��\\word.txt"));//��ȡ����
//		//glist = util.read("F:\\11.txt");//��ȡ����
//		if(glist != null){
//			ThreeSet threeSet = new ThreeSet(glist);
//			printMap(threeSet.getFirst());
//			//printMap(threeSet.getFollow());
//			//printPredict(threeSet.getPredict());
//		}
//		//�鿴map
	}
}