package compile.snl.grammars;

import java.util.ArrayList;

import compile.snl.wrods.Word;

///////////////////////////////
// ����: 
// С��: 
// ����: 
/**
 * predict����һ���﷨��Ӧһ��word����
 * @author ��
 * @version 1.0
 * @created 06-6��-2018 21:13:56
 */
///////////////////////////////

public class GrammarToWord {

	/**
	 * һ���﷨
	 */
	private Grammar grammar;
	/**
	 * �﷨��Ӧ�ļ���
	 */
	private ArrayList<Word> words;

	public GrammarToWord(){
		grammar = new Grammar();
		words = new ArrayList<Word>();
	}

	public Grammar getGrammar() {
		return grammar;
	}

	public void setGrammar(Grammar grammar) {
		this.grammar = grammar;
	}

	public ArrayList<Word> getWords() {
		return words;
	}

	public void setWords(ArrayList<Word> words) {
		this.words = words;
	}

}